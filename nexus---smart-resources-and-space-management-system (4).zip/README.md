
# NEXUS - Smart Campus OS

NEXUS is a high-fidelity, futuristic campus resource and space management system. It features real-time spatial grids, live SVG mapping, AI-driven resource monitoring, and a Stark-style "Command Center" for administrators.

## 🚀 Features

- **Command Center:** High-level overview of system nodes, latency, and utilization metrics.
- **Live 3D Map:** Isometric SVG map with real-time status telemetry and hover HUDs.
- **AI Assistant:** Neural-link chat interface for optimizing room and equipment search.
- **Facility Visualizer:** Generative AI tool (powered by Gemini) to render facility concepts.
- **Resource Explorer:** Interactive grid to browse, filter, and book campus facilities.
- **Dynamic Themes:** Fully responsive design with an immersive Dark Mode (Stark Aesthetic).

## 🛠 Tech Stack

- **Framework:** React 19
- **Styling:** Tailwind CSS (Custom Glassmorphism)
- **Intelligence:** Google Gemini API (@google/genai)
- **Tooling:** Vite + TypeScript

## 📦 How to Sync to GitHub

1. Create a new repository on [GitHub](https://github.com/new).
2. Open your terminal in this project's root folder.
3. Run the following commands:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO_NAME.git
   git push -u origin main
   ```

## 🛠 Setup & Installation

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Configure Environment:**
   NEXUS requires an API Key for Gemini features. The app expects `process.env.API_KEY` to be available. In a local Vite environment, you may need to update the code to use `import.meta.env.VITE_GEMINI_API_KEY` or use a proxy.

3. **Run Development Server:**
   ```bash
   npm run dev
   ```

## 🛡 License

This project is licensed under the MIT License.
